/*
 * pid.h
 *
 *  Created on: May 2, 2024
 *      Author: orion
 */

#ifndef PID_H_
#define PID_H_



int16_t fan_control(uint8_t ch, int setrpm, int currpm);

#endif /* PID_H_ */
