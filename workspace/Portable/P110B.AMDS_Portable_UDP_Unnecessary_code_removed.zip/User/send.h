/*
 * send.h
 *
 *  Created on: Aug 6, 2024
 *      Author: machi
 */

#ifndef SEND_H_
#define SEND_H_


void Send_Portable_Status(void);


#endif /* SEND_H_ */
